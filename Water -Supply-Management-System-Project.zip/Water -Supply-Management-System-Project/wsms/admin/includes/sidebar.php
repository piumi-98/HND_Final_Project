<div class="sidebar-menu">
          <header class="logo1">
            <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
          </header>
            <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
                  <ul id="menu" >
                    <li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>
                    <li id="menu-academico" ><a href="#"><i class="fa fa-cogs" aria-hidden="true"></i><span> Company Info</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                       <ul id="menu-academico-sub" >
                       <li id="menu-academico-avaliacoes" ><a href="add-company.php">Add</a></li>
                      <li id="menu-academico-avaliacoes" ><a href="manage-company.php">Manage</a></li>
                      </ul>
                    </li>
                  


                   <li id="menu-academico" ><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Water Bottel Info</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                       <ul id="menu-academico-sub" >
                       <li id="menu-academico-avaliacoes" ><a href="add-bottle.php">Add</a></li>
                      <li id="menu-academico-avaliacoes" ><a href="manage-bottle.php">Manage</a></li>
                     
                      </ul>
                    </li>
                  
                  
                  
                  <li><a href="#"><i class="fa fa-check-square-o nav_icon"></i><span>Order Management</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                    <ul>
                    <li><a href="new-order.php"> New Order</a></li>
                    <li><a href="accept-order.php">Order Accept</a></li>
                   <li><a href="order-onthway.php">Order On its Way</a></li>
                    <li><a href="order-delivered.php">Order Delivered </a></li>
                     <li><a href="order-cancelled.php">Order Cancelled</a></li>
                     <li><a href="all-orders.php">All Orders</a></li>
                  </ul>
                  </li>
                  
                   <li><a href="manage-users.php"><i class="fa fa-users"></i> <span>Reg Users</span><div class="clearfix"></div></a></li>
                   <li><a href="search.php"><i class="fa fa-search"></i> <span>Search</span><div class="clearfix"></div></a></li>
                   <li><a href="#"><i class="fa fa-newspaper-o"></i><span>Reports</span> <span class="fa fa-angle-right" style="float: right"><div class="clearfix"></div></a>
                    <ul>
                    <li><a href="bwdates-reports-ds.php"> B/w dates</a></li>
                    <li><a href="requestcount-reports-ds.php">Order Count</a></li>
                    <li><a href="sales-reports.php">Sales Reports</a></li>

                  </ul>
                  </li>


                   <li><a href="#"><i class="fa fa-newspaper-o"></i><span>Latest News/Updates</span> <span class="fa fa-angle-right" style="float: right"><div class="clearfix"></div></a>
                    <ul>
                    <li><a href="add-latestnews.php"> Add</a></li>
                    <li><a href="manage-latestnews.php">Manage</a></li>
                  </ul>
                  </li>

                    <li id="menu-academico" ><a href="#"><i class="fa fa-file-text-o"></i>  <span>Pages</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
                     <ul id="menu-academico-sub" >
                      <li id="menu-academico-boletim" ><a href="aboutus.php">About Us</a></li>
                      <li id="menu-academico-avaliacoes" ><a href="contactus.php">Contact Us</a></li>
                    
                      </ul>
                   </li>


                  </ul>
                </div>
                </div>