<div class="footer">
          <p style="color: red"> Water Supply Management System . </p>
        </div>